application =
{

	content =
	{
		width = 1080,
		height = 1920, 
		scale = "zoomStretch",
		fps = 30,
	},  
}
